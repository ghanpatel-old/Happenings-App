var api = require('./controllers/api.js');

api.fillCategories();
