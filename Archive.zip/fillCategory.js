// The main application script, ties everything together.

var express = require('express');
var mongoose = require('mongoose');

//var RedisStore = require('connect-redis')(express);
var app = express.createServer(express.logger());

var MemoryStore = require('express').session.MemoryStore;
var db = mongoose.connect('mongodb://heroku:1111@staff.mongohq.com:10010/app2729959');

function fillCategories() {
	console.log("fillData launch");
	request('http://173.203.29.228:8227/fo.php/iphone/categoryDump', function (error, response, body) {
	  if (!error && response.statusCode == 200) {
		var jsonObj = JSON.parse(body);
	
		//fill events
		jsonObj.forEach(function(element, index, array){
			var instance = new Category();
			instance.id = element.id.toString();
			instance.name = element.name;
			instance.description = element.description;
		 	instance.for_orgs = element.for_orgs;
			instance.for_venues = element.for_venues;
			instance.for_events = element.for_events;
			instance.is_featured = element.is_featured;
			instance.parent_category_id = element.parent_category_id;
			instance.save(function (err) {
				if (!err) {
					console.log('Success!');
				} else {
					console.log('Save Failed.');
				}
			  });		
		});
	  }
	});
}

fillCategories();
